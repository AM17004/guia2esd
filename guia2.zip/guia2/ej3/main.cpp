#include <iostream>
#include<stdio.h>
#include<stdlib.h>

int main() {
    int matriza[20][20], matrizb[20], matrizc[20][20], f1, f2, c1, c2, x, y, con, acu, op;
    system("cls");
    printf("1. Sumar");
    scanf("%d", &op);

    do {
        printf("\nFilas de la matriz A: ");
        scanf("%d", &f1);
        printf("\nColumnas de la matriz A: ");
        scanf("%d", &c1);
        printf("\nFilas de la matriz B: ");
        scanf("%d", &f2);
        printf("\nColumnas de la matriz B: ");
        scanf("%d", &c2);
    } while (op==1 && (f1!=f2 || c2==c1));
    system("cls");

    printf("Llemar primer matriz");

    for(x=0; x<f1; x++){ //filas
        for(y=0; y<c1; y++){ //columnas
         printf("Ingrse la posicion [%d][%d]",x, y);
         scanf("%d", &matriza[x])[y];


        }
        printf("Llenar segunda matriz");
        for(x=0; x<f2; x++){ //filas
            for(y=0; y<c2; y++){ //columnas
                printf("Ingrese la posicion [%d][%d]",x, y);
                scanf("%d", &matrizb[x][y]);
    }
            for(x=0; x<f1; x++){

            printf("\n");
            system("cls");
            printf("Primer matriz");
            for(y=0; y<c1; y++){
                printf("%d", matriza[x][y]);

            }
                for(x=0; x<f2; x++){
                    printf("SEgunda matriz");
                    for(y=0; y<c2; y++){
                        printf("%d", matrizb[x][y]);

                    }

            }
        }
    switch(op){
                case 1:
                for(x=0; x<f1; x++){
                    for(y=0; y<c2; y++){
                        matrizc[x][y] = matriza[x][y] + matrizb[x][y];
                        for(x=0; x<f1; x++){
                        printf("\n");
                        for(y=0; y<c2; y++)
                            printf("%d", matrizc[x][y]);
                        for(acu=0, con=0; con<c1; con++);
                        acu= acu + matriza[x][y] * matrizb[x][y];
                        matrizc[x][y]=acu;


                }
                break;

            }}}}}}

    return 0;
}