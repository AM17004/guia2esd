#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
int filas, columnas, i, j;
srand (time(NULL));

printf("Ingrese el tamaño de filas de las matrices \n");
scanf("%i", &filas);
printf("Ingrese el tamaño de columnas de las matrices \n");
scanf("%i", &columnas);

int matriz[filas][columnas], matriz2[filas][columnas], matriz3[filas][columnas];
    for(i=0; i<filas; i++) {
        for (j = 0; j < columnas; j++) {
            matriz[i][j] = rand() % 100;
            matriz2[i][j] = rand() % 100;

            for (i = 0; i < filas; i++) {
                for (j = 0; j < columnas; j++) {
                    matriz3[i][j] = matriz[i][j] + matriz2[i][j];
                }

            }
            for (i = 0; i < filas; i++) {
                for (j = 0; j < columnas; j++) {
                    printf("[%i]", matriz[i][j]);

                }
                printf("\n");

            }}}

            return 0;
        }